package com.sgturnos.sgturnos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SgturnosApplicationTests {

	@Test
	void contextLoads() {
	}

}
